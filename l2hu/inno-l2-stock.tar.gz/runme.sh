#!/bin/sh
# Developed by vnish team

TMPDIR=/tmp/fw.$$
CURDIR=$(pwd)

cleanup() {
	cd "$CURDIR"
	[ -d "$TMPDIR" ] && rm -rf "$TMPDIR"
}

trap cleanup EXIT SIGINT



mkdir -p $TMPDIR

echo "Extracting fw.tar.gz"
tar xzf fw.tar.gz -C "$TMPDIR"
rm -f fw.tar.gz

if [ -f apikeys.json ]; then
	cp apikeys.json "$TMPDIR"
fi

if [ -f anthill.json ]; then
	cp anthill.json "$TMPDIR"
fi

echo "Executing install.sh"
cd "$TMPDIR"
sh install.sh
exit $?
